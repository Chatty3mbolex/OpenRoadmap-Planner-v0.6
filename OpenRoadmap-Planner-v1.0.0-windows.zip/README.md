# OpenRoadmap-Planner-v1.0

Hi,
short:

I am Embolex, pretty new in programming and use of Ai,
Agents Tools and this stuff. Anyways i couldn't get around to program a very nice helper for:

#Developers

#Engineers

#Architects

#Artists

... Or just

#Household.

Because i am a very ambitious learner and i like to go with time, like i am lazy and don't want to crawl a lot,
i made a tool to make my life easier and hopefully yours too!

Here is what i have made for us:


A simple but powerful roadmap planner with graph and storyboard function to keep all in view!
It comes with an integrated AI-Agent/Chat and tools. 
You can connect via MCP server, acpx or directly with API_KEY to a LLM model like ChatGPT.

You got a WebUiChat on the right side, where u can just chat with ur LLM or give it specific commands.


A powerful tool to plan your projects, works, stories, ideas, life, whatever u want to plan. 

You can  flag entries, connect them to a spider web and keep the overview about dependencies and impacts!
While you are talking with the LLM and made a mistake pressing "Enter" too early -> no problem <- just stop him doing, he will ask you
if you forgot something and you can proceed!

The Interface is easy to handle and almost self explaining!
You have a lot of included features like flagging, showing routes, comment and even a field for code examples, solutions or more.
Glowing lines show the exact connection targets and origins from interconnections!
Origins and Target are shown up with a small arrow on the beginning of the connector line.

The storyboard function makes it possible to add stories to your OpenRoadmap Plan.
You can name and categorize the storyboard entries to keep track all over the story!


Agent behaviors:

The Ui shows u where the Agent is working on an where the Agent has worked last by letting glow up the specific point he touched!
So you will always "see" what you agent did, or "where" he does in case if it stucks!
Also i implemented error toasts to the WebUiChat in case of errors.
A counter Shows if the Agent is working and since when the process is in work!
Also is the last given input shown directly below the working counter!


This an homegrown project and Local-first prototype, no hardening, not reviewed, don’t expose to the internet.!!

USE IT ON YOU OWN RISK, DON'T BLAME ME FOR SECURITY LEAKS, YOU HAVE TO SECURE YOURSELF AGAINST SECURITY BREACHES! 


Feel free to use and update as you please! Just keep in mind: „Credits appreciated“. I would like to get known over time!
In case of Issues or change suggestions or wished feature, don't be too shy to ask for it!
Discussions are wished! Let me know what you think! Im able to take criticism (just don't hit me!!).
Just have in mind --> ITS MY VERY FIRST PROGRAM RELEASE EVER!! I AM NOT A CODER, JUST PROGRAMMER BECOMING CODER!


#NO_MALICIOUS_CODE

#CLEAN_CODE

#OPEN_SOURCE

#FREE

#Price_your_own! 
PayPal: rickembolex@gmail.com (please with greetings!)


Author: Embolex 22.03.2026 - 00:33AM (Kempenich/Germany)
Special Credits got to: OpenAI/ChatGpt5.2-codex for the great help to develop and offer such a smart program!
Credits to anthropic Claude for fixing some "mindset"  problems with me!
